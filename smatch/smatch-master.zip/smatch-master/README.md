# Smatch (semantic match) tool

This is source code of [smatch](http://amr.isi.edu/evaluation.html), an evaluation tool for AMR (Abstract Meaning Representation). 

The code was mostly developed during 2012-2013, and has undergone many fixes and updates. It is now hosted on github for better collaboration.

More details and updates about AMR and smatch can be found in USC/ISI's AMR site: http://amr.isi.edu/index.html
